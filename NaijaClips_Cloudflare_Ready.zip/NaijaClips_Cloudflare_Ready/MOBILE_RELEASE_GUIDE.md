# NaijaClips — Android and iOS release guide

## Current state
The repository has `package.json` and `capacitor.config.json` for Capacitor. Native Android and iOS project folders and signed release binaries are not included in this ZIP. A successful app-store release cannot be claimed until the projects are generated, tested, signed, uploaded and approved.

## Requirements
- Node.js/npm and Git.
- Android: Android Studio and Android SDK; a Google Play Console developer account for release.
- iOS: macOS with Xcode for native build/signing, an Apple Developer account, and App Store Connect access.
- A live HTTPS website and working privacy policy, terms, support contact, content reporting, account deletion and moderation process before submission.

## Generate native shells
Run these commands from the extracted project directory on a computer with Node.js/npm installed:

```sh
npm install
npx cap add android
npx cap add ios
npx cap sync
npx cap open android
npx cap open ios
```

Run `npx cap add ios` on macOS with the iOS toolchain available. If a native platform folder already exists, do not add it again; run `npx cap sync` instead.

## Android
1. Open the Android project in Android Studio.
2. Set the final application ID and versioning before release; `com.naijaclips.app` is only the current starter ID.
3. Test signup, uploads, video playback, report flow, download/share behavior, accessibility, network failure, and account deletion on physical Android devices.
4. Create and securely back up a release signing key. Never commit signing credentials to source control.
5. Build a signed Android App Bundle (`.aab`), upload it to an internal testing track, fix all issues, then complete Play Console declarations and request production release.

## iPhone/iPad
1. Open the generated iOS project in Xcode on a Mac.
2. Set a unique bundle identifier, version/build number, signing team, icons and launch settings.
3. Test on physical iPhones/iPads and verify privacy permissions, account deletion, reporting, video uploads, playback, and network interruptions.
4. Archive and upload via Xcode to App Store Connect, use TestFlight, resolve review issues, then submit for App Store review.

## Store policies and content
Because users can post public videos, implement reliable report/block controls, prompt moderation and removal, a copyright/takedown path, clear community guidelines, privacy disclosures, support contact and account deletion. Explain what data is collected and how uploaded videos are used. Complete the current platform privacy/data-safety forms accurately. Do not publish template legal pages unchanged without review.

## Advertising and creator payouts
Do not add live ad IDs or transfer credentials until the relevant provider account is approved. Use test mode, validate server-side earnings and webhook signatures, enforce creator eligibility and payout limits, and reconcile all transfers. Never place provider secrets in the app or browser bundle. Store review is separate from payment-provider approval.
