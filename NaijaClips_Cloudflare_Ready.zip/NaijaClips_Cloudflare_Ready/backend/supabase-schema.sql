-- NaijaClips starter backend for Supabase (Postgres + Auth + Storage)
-- Run this in Supabase SQL Editor after creating a project.

create table if not exists public.clips (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  caption varchar(180) not null,
  storage_path text not null unique,
  original_filename text,
  content_type text not null,
  size_bytes bigint not null check (size_bytes > 0 and size_bytes <= 262144000),
  created_at timestamptz not null default now()
);

create index if not exists clips_created_at_idx on public.clips (created_at desc);
create index if not exists clips_user_id_idx on public.clips (user_id);

alter table public.clips enable row level security;

-- Public read allows a public video feed. Do not store private videos in this table.
drop policy if exists "Anyone can read public clips" on public.clips;
create policy "Anyone can read public clips" on public.clips for select using (true);

drop policy if exists "Signed-in users can publish their own clips" on public.clips;
create policy "Signed-in users can publish their own clips" on public.clips for insert to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Owners can delete their own clips" on public.clips;
create policy "Owners can delete their own clips" on public.clips for delete to authenticated
using (auth.uid() = user_id);

-- Storage bucket setup: create a PUBLIC bucket named `clips` in Storage dashboard.
-- Set a 250 MB max file size and allow video MIME types as appropriate.
-- Storage object path must be: <authenticated-user-uuid>/<random-file-name>.
-- Public read policy is required for public clip playback; only authenticated owners may upload/delete.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('clips', 'clips', true, 262144000,
  array['video/mp4','video/webm','video/quicktime','video/ogg','video/x-m4v'])
on conflict (id) do update set public = true, file_size_limit = 262144000,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "Public can view clip files" on storage.objects;
create policy "Public can view clip files" on storage.objects for select
using (bucket_id = 'clips');

drop policy if exists "Signed-in users upload into own folder" on storage.objects;
create policy "Signed-in users upload into own folder" on storage.objects for insert to authenticated
with check (bucket_id = 'clips' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "Owners delete files in own folder" on storage.objects;
create policy "Owners delete files in own folder" on storage.objects for delete to authenticated
using (bucket_id = 'clips' and (storage.foldername(name))[1] = auth.uid()::text);
