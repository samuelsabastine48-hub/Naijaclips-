# NaijaClips cloud backend setup (Supabase)

This starter adds an optional shared public feed and email/password accounts. It requires you to create and configure your own Supabase project; no account, project key, storage, or paid plan is included.

## 1. Create the backend
1. Create a project at https://supabase.com/ and keep its database password private.
2. In the Supabase SQL Editor, run `backend/supabase-schema.sql` from this ZIP.
3. Open Project Settings → API and copy the Project URL and the public anon/publishable key.
4. Edit `supabase-config.js` and replace both placeholders. Only use the public anon/publishable key in the website. Never expose a `service_role` or secret key.
5. Deploy the whole folder to Netlify. `index.html`, `supabase-config.js`, `cloud.js`, `manifest.webmanifest`, `sw.js`, and `icons/` must be at the site root.

## 2. Enable account email confirmation
In Supabase Authentication settings, configure the site's Site URL and redirect URLs to your exact HTTPS Netlify domain. Decide whether to require email confirmation before public posting. Test sign-up, sign-in, sign-out, posting, playback and deletion using two different accounts/devices.

## 3. What the cloud starter does
- Creates email/password accounts through Supabase Auth.
- Uploads video files to Supabase Storage (up to 250 MB per file in this starter).
- Stores public clip metadata in Postgres and lists it in a shared feed.
- Allows authenticated users to delete only their own clips, using row-level security.
- Public clips can be watched by visitors; posting requires sign-in.

The existing local-device prototype is retained. The cloud panel works only after configuration. Do not publish with the placeholder configuration and expect cloud features to work.

## 4. Before a real public launch
This is an MVP backend scaffold, not a production-scale video service. Add automated video transcoding and adaptive streaming/CDN, rate limits and quotas, upload scanning, reporting/blocking/moderation, copyright/takedown process, account recovery, privacy policy/terms, data export/deletion, backups, monitoring, abuse prevention and security review. Public storage can incur costs and exposes posted clips to anyone with their URLs. Establish budget alerts and quotas first.

## 5. Monetization reality
No revenue or creator payouts are enabled by this code. Ad networks, sponsors, analytics consent, eligibility rules, fraud checks, tax/compliance review and a payment/payout provider need separate integration. Never promise users guaranteed earnings based only on views.
