-- NaijaClips community safety foundation. Run after supabase-schema.sql.
-- Admin moderation actions must use a trusted server/service-role environment only.

alter table public.clips
  add column if not exists moderation_status text not null default 'published'
  check (moderation_status in ('pending','published','hidden','removed'));

-- Replace the original public read policy so hidden/removed clips do not appear in the public feed.
drop policy if exists "Anyone can read public clips" on public.clips;
drop policy if exists "Anyone can read published clips" on public.clips;
create policy "Anyone can read published clips" on public.clips
  for select using (moderation_status = 'published');

create table if not exists public.content_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_user_id uuid not null references auth.users(id) on delete cascade,
  clip_id uuid references public.clips(id) on delete set null,
  reported_user_id uuid references auth.users(id) on delete set null,
  reason text not null check (reason in ('nudity','violence','hate','harassment','spam','copyright','underage_safety','other')),
  details varchar(1000) not null default '',
  status text not null default 'open' check (status in ('open','reviewing','actioned','dismissed')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);
create index if not exists content_reports_status_created_idx on public.content_reports(status, created_at desc);
create index if not exists content_reports_clip_idx on public.content_reports(clip_id);
alter table public.content_reports enable row level security;
drop policy if exists "Users can submit reports" on public.content_reports;
create policy "Users can submit reports" on public.content_reports
  for insert to authenticated
  with check (auth.uid() = reporter_user_id and (clip_id is not null or reported_user_id is not null));
drop policy if exists "Users can view own reports" on public.content_reports;
create policy "Users can view own reports" on public.content_reports
  for select to authenticated using (auth.uid() = reporter_user_id);
-- No client update/delete policies: moderation staff use trusted server credentials.

create table if not exists public.user_blocks (
  blocker_user_id uuid not null references auth.users(id) on delete cascade,
  blocked_user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_user_id, blocked_user_id),
  check (blocker_user_id <> blocked_user_id)
);
alter table public.user_blocks enable row level security;
drop policy if exists "Users manage their own blocks" on public.user_blocks;
create policy "Users manage their own blocks" on public.user_blocks
  for all to authenticated
  using (auth.uid() = blocker_user_id)
  with check (auth.uid() = blocker_user_id);

-- The reports table intentionally contains no public read access. Build a staff-only review UI
-- using an Edge Function with an explicit admin allowlist; never expose service-role keys.
