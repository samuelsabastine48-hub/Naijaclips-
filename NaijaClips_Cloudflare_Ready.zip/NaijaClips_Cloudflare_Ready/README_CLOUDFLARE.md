# NaijaClips — Cloudflare Workers static-assets package

This package adapts the existing NaijaClips web MVP to Cloudflare Workers static assets. It does not create or change your Cloudflare/Supabase account and it does not purchase R2.

## Cloudflare Workers Build settings

- Root directory / working directory: `.`
- Build command: `npm run build`
- Deploy command: `npx wrangler@latest deploy`
- Preview command: `npx wrangler@latest dev`

`wrangler.jsonc` sets `workers_dev` to `true` and publishes only the `public/` directory. The SQL and setup documents remain outside public assets.

## Important

- Upload the *contents of this ZIP* to the root of the GitHub repository connected to Cloudflare, or commit these files into the existing repository. Do not upload the ZIP itself as the app source.
- Do not delete the previous GitHub files until you have a backup. If the repo contains work you need, merge these files instead of replacing it wholesale.
- The build command only checks required files/configuration. It does not prove the Supabase backend works.
- The site uses the configured Supabase public publishable key in `public/supabase-config.js`. Public publishable keys are intended for browser use; never put a service-role or secret key there.
- Before cloud uploads work, run `backend/supabase-schema.sql` in the intended Supabase project's SQL Editor and verify storage policies. Apply `backend/community-safety.sql` only after reviewing it and the existing schema.
- This package is an MVP web deployment, not a signed Android/iOS store build. Privacy/terms templates must be completed before public launch.
- R2 is not required for this first deployment; existing Supabase Storage is the intended video store.
