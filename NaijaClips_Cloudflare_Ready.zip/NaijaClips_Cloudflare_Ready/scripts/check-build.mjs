import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
const required = [
  'wrangler.jsonc',
  'public/index.html',
  'public/supabase-config.js',
  'public/cloud.js',
  'public/manifest.webmanifest',
  'public/sw.js',
  'public/icons/icon-192.png',
  'public/icons/icon-512.png'
];
const missing = required.filter((p) => !existsSync(resolve(p)));
if (missing.length) {
  console.error('NaijaClips build check failed. Missing files:', missing.join(', '));
  process.exit(1);
}
const config = readFileSync('public/supabase-config.js', 'utf8');
if (!config.includes('https://lvgpfbjajxytbfyeslcx.supabase.co') || !config.includes('sb_publishable_')) {
  console.error('Supabase configuration is missing or looks like a placeholder. Check public/supabase-config.js.');
  process.exit(1);
}
console.log('NaijaClips build check passed: required web assets and Supabase public configuration are present.');
console.log('This check does not test Supabase credentials, database policies, or live upload/playback.');
