import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const config = window.NAIJACLIPS_SUPABASE || {};
const $ = (id) => document.getElementById(id);
const ready = typeof config.url === 'string' && config.url.startsWith('https://') &&
  !config.url.includes('YOUR-PROJECT') && typeof config.anonKey === 'string' &&
  config.anonKey.length > 20 && !config.anonKey.includes('YOUR_SUPABASE');
const cloudStatus = $('cloudStatus');
const cloudFeed = $('cloudFeed');
let supabase = null;
let currentUser = null;

function status(message, error = false) {
  cloudStatus.textContent = message;
  cloudStatus.style.color = error ? '#ff9b9b' : 'var(--green)';
}
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function humanSize(bytes) {
  return bytes >= 1048576 ? `${(bytes / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;
}
function publicVideoUrl(path) {
  return supabase.storage.from('clips').getPublicUrl(path).data.publicUrl;
}
function setSignedInUI(user) {
  currentUser = user || null;
  $('cloudAuthForm').classList.toggle('hidden', !!user);
  $('cloudSignOutAlt').classList.toggle('hidden', !user);
  $('cloudUploadForm').classList.toggle('hidden', !user);
  $('cloudUser').textContent = user ? `Signed in: ${user.email || 'account'}` : 'Not signed in';
}
function renderCloudCards(clips) {
  if (!clips.length) {
    cloudFeed.innerHTML = '<div class="empty-state"><div style="font-size:2rem">🌍</div><h3>No public clips yet</h3><p>When someone posts a cloud clip, it can appear here for other visitors too.</p></div>';
    return;
  }
  cloudFeed.innerHTML = '';
  for (const clip of clips) {
    const card = document.createElement('article');
    card.className = 'card';
    const url = publicVideoUrl(clip.storage_path);
    card.innerHTML = `<div class="video-wrap"><video controls playsinline preload="metadata" src="${escapeHtml(url)}" aria-label="${escapeHtml(clip.caption)}"></video></div><div class="card-body"><div class="caption">${escapeHtml(clip.caption)}</div><div class="meta"><span>${new Date(clip.created_at).toLocaleDateString()}</span><span>${humanSize(clip.size_bytes)}</span></div><div class="card-actions"><button data-download>↓ Download</button><button class="secondary" data-share>↗ Share</button>${currentUser && currentUser.id !== clip.user_id ? '<button class="secondary" data-report>⚑ Report</button>' : ''}${currentUser && currentUser.id === clip.user_id ? '<button class="danger" data-delete>Delete</button>' : ''}</div></div>`;
    card.querySelector('[data-download]').addEventListener('click', () => {
      const a = document.createElement('a'); a.href = url; a.download = clip.original_filename || 'naijaclips-video.mp4'; a.target = '_blank'; a.rel = 'noopener'; document.body.appendChild(a); a.click(); a.remove();
    });
    card.querySelector('[data-share]').addEventListener('click', async () => {
      try {
        if (navigator.share) await navigator.share({title:'NaijaClips', text:clip.caption, url});
        else { await navigator.clipboard.writeText(url); status('Video link copied.'); }
      } catch (e) { if (e?.name !== 'AbortError') status('Could not share this link.', true); }
    });
    const report = card.querySelector('[data-report]');
    if (report) report.addEventListener('click', async () => {
      if (!currentUser) { status('Sign in before reporting a clip.', true); return; }
      const choices = 'nudity, violence, hate, harassment, spam, copyright, underage_safety, other';
      const reason = prompt(`Why are you reporting this clip? Enter one reason exactly:\n${choices}`, 'spam');
      if (!reason) return;
      const normalized = reason.trim().toLowerCase();
      if (!choices.split(', ').includes(normalized)) { status('Please enter one of the listed report reasons.', true); return; }
      const details = prompt('Optional details (max 1000 characters):', '') || '';
      report.disabled = true;
      const { error } = await supabase.from('content_reports').insert({
        reporter_user_id: currentUser.id, clip_id: clip.id, reported_user_id: clip.user_id,
        reason: normalized, details: details.slice(0, 1000)
      });
      report.disabled = false;
      if (error) { status('Report could not be submitted. Apply backend/community-safety.sql first. ' + error.message, true); return; }
      status('Report submitted. Our moderation process still needs an operator to review it.');
    });
    const del = card.querySelector('[data-delete]');
    if (del) del.addEventListener('click', async () => {
      if (!confirm('Delete this public clip? This removes the clip from the shared feed.')) return;
      del.disabled = true;
      const { error: storageError } = await supabase.storage.from('clips').remove([clip.storage_path]);
      if (storageError) { status(storageError.message, true); del.disabled = false; return; }
      const { error } = await supabase.from('clips').delete().eq('id', clip.id).eq('user_id', currentUser.id);
      if (error) { status(error.message, true); return; }
      status('Your clip was deleted.'); await loadCloudFeed();
    });
    cloudFeed.appendChild(card);
  }
}
async function loadCloudFeed() {
  if (!supabase) return;
  cloudFeed.innerHTML = '<div class="empty-state">Loading shared clips…</div>';
  const { data, error } = await supabase.from('clips').select('id,user_id,caption,storage_path,original_filename,content_type,size_bytes,created_at').order('created_at', {ascending:false}).limit(60);
  if (error) { cloudFeed.innerHTML = '<div class="empty-state">Could not load cloud feed. Check the setup guide and Supabase policies.</div>'; status(error.message, true); return; }
  renderCloudCards(data || []);
  $('cloudCount').textContent = String((data || []).length);
}
async function init() {
  if (!ready) {
    status('Cloud mode is not configured yet. Add your Supabase URL and public anon/publishable key in supabase-config.js.', true);
    cloudFeed.innerHTML = '<div class="empty-state"><div style="font-size:2rem">☁️</div><h3>Cloud feed setup needed</h3><p>Follow backend/CLOUD_SETUP.md. Until then, use the local-device feed below.</p></div>';
    $('cloudAuthForm').classList.remove('hidden'); $('cloudUploadForm').classList.add('hidden'); $('cloudAuthForm').querySelectorAll('input,button').forEach(el => el.disabled = true);
    return;
  }
  supabase = createClient(config.url, config.anonKey, {auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
  const { data: { session } } = await supabase.auth.getSession();
  setSignedInUI(session?.user);
  supabase.auth.onAuthStateChange((_event, sessionNow) => { setSignedInUI(sessionNow?.user); loadCloudFeed(); });
  await loadCloudFeed();
}
$('cloudAuthForm').addEventListener('submit', async (event) => {
  event.preventDefault(); if (!supabase) return;
  const email = $('cloudEmail').value.trim(); const password = $('cloudPassword').value;
  const action = event.submitter?.dataset.authAction || 'signin';
  status(action === 'signup' ? 'Creating account…' : 'Signing in…');
  const result = action === 'signup'
    ? await supabase.auth.signUp({email, password})
    : await supabase.auth.signInWithPassword({email, password});
  if (result.error) { status(result.error.message, true); return; }
  if (action === 'signup' && !result.data.session) status('Account created. Check your email to confirm it, then sign in.');
  else { setSignedInUI(result.data.user); status('You are signed in.'); await loadCloudFeed(); }
});
$('cloudSignOutAlt').addEventListener('click', async () => { if (!supabase) return; const {error} = await supabase.auth.signOut(); if (error) status(error.message, true); else {setSignedInUI(null); status('Signed out.'); await loadCloudFeed();} });
$('cloudUploadForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!supabase || !currentUser) { status('Sign in before posting.', true); return; }
  const file = $('cloudVideoFile').files[0]; const caption = $('cloudCaption').value.trim();
  if (!file || !caption) return;
  if (!file.type.startsWith('video/')) { status('Please choose a video file.', true); return; }
  if (file.size > 250 * 1024 * 1024) { status('The current upload limit is 250 MB.', true); return; }
  const btn = $('cloudPublishBtn'); btn.disabled = true; status('Uploading video to cloud storage…');
  const ext = (file.name.split('.').pop() || 'mp4').toLowerCase().replace(/[^a-z0-9]/g, '') || 'mp4';
  const path = `${currentUser.id}/${crypto.randomUUID()}.${ext}`;
  const { error: uploadError } = await supabase.storage.from('clips').upload(path, file, {contentType:file.type, upsert:false});
  if (uploadError) { status(uploadError.message, true); btn.disabled = false; return; }
  const { error: insertError } = await supabase.from('clips').insert({user_id:currentUser.id,caption,storage_path:path,original_filename:file.name,content_type:file.type,size_bytes:file.size});
  if (insertError) {
    await supabase.storage.from('clips').remove([path]);
    status(insertError.message, true); btn.disabled = false; return;
  }
  $('cloudUploadForm').reset(); status('Published to the shared cloud feed.'); await loadCloudFeed(); btn.disabled = false;
});
init().catch(error => { console.error(error); status('Cloud setup error: ' + (error.message || 'unknown error'), true); });
