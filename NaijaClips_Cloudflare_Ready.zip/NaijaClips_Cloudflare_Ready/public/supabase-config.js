/* NaijaClips cloud configuration.
   Uses the existing Supabase project and its public publishable key.
   NEVER put a service_role or secret key in browser code.
*/
window.NAIJACLIPS_SUPABASE = {
  url: 'https://lvgpfbjajxytbfyeslcx.supabase.co',
  anonKey: 'sb_publishable_IodssB9DUB9stpFMi9rAjA_GSss5Dtn'
};
